Please read loading_maps for demo usage.

Usually you need only ne_10_land and ne_10m_ocean. The others (50m and 110m) have lower resolutions and are only for cheaper computers or early tests.
